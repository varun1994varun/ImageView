///////////////////////////////////////////////////////////////////////////////
//                                                                             
//  Copyright (C) 2008-2012  Artyom Beilis (Tonkikh) <artyomtnk@yahoo.com>     
//                                                                             
//  See accompanying file COPYING.TXT file for licensing details.
//
///////////////////////////////////////////////////////////////////////////////
#ifndef CPPCMS_SERIALIZATION_H
#define CPPCMS_SERIALIZATION_H

#include <cppcms/serialization_classes.h>
#include <cppcms/archive_traits.h>

#endif
